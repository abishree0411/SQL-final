
CREATE TABLE books (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100),
    isbn VARCHAR(20),
    publication_year INT,
    copies INT
);

CREATE TABLE authors (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100)
);

CREATE TABLE books_authors (
    book_id INT REFERENCES books(id),
    author_id INT REFERENCES authors(id),
    PRIMARY KEY (book_id, author_id)
);

CREATE TABLE members (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    membership_date DATE
);

CREATE TABLE loans (
    id SERIAL PRIMARY KEY,
    book_id INT REFERENCES books(id),
    member_id INT REFERENCES members(id),
    loan_date DATE,
    due_date DATE,
    return_date DATE
);
