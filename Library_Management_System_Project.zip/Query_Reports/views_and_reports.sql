
-- View for currently borrowed books
CREATE VIEW borrowed_books AS
SELECT l.id, b.title, m.name AS borrower, l.loan_date, l.due_date
FROM loans l
JOIN books b ON l.book_id = b.id
JOIN members m ON l.member_id = m.id
WHERE l.return_date IS NULL;

-- View for overdue books
CREATE VIEW overdue_books AS
SELECT l.id, b.title, m.name AS borrower, l.loan_date, l.due_date
FROM loans l
JOIN books b ON l.book_id = b.id
JOIN members m ON l.member_id = m.id
WHERE l.return_date IS NULL AND l.due_date < CURRENT_DATE;

-- Report: Count of borrowed books per member
SELECT m.name, COUNT(*) AS borrowed_books
FROM loans l
JOIN members m ON l.member_id = m.id
WHERE l.return_date IS NULL
GROUP BY m.name;
