
-- Insert authors
INSERT INTO authors (name) VALUES ('J.K. Rowling'), ('George Orwell'), ('J.R.R. Tolkien');

-- Insert books
INSERT INTO books (title, isbn, publication_year, copies) VALUES
('Harry Potter and the Philosopher''s Stone', '9780747532699', 1997, 5),
('1984', '9780451524935', 1949, 3),
('The Hobbit', '9780261102217', 1937, 4);

-- Associate books with authors
INSERT INTO books_authors (book_id, author_id) VALUES
(1, 1), (2, 2), (3, 3);

-- Insert members
INSERT INTO members (name, email, membership_date) VALUES
('Alice Johnson', 'alice@example.com', '2023-01-10'),
('Bob Smith', 'bob@example.com', '2022-06-15');

-- Insert loans
INSERT INTO loans (book_id, member_id, loan_date, due_date, return_date) VALUES
(1, 1, '2025-07-01', '2025-07-15', NULL),
(2, 2, '2025-06-20', '2025-07-05', '2025-07-04'),
(3, 1, '2025-06-25', '2025-07-10', NULL);
