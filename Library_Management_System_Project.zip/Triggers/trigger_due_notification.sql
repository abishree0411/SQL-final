
-- Function to notify if book is due within 3 days
CREATE OR REPLACE FUNCTION notify_due_books() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.due_date <= CURRENT_DATE + INTERVAL '3 days' THEN
    RAISE NOTICE 'Book loan for Member ID % is due on %', NEW.member_id, NEW.due_date;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger on loan insert
CREATE TRIGGER due_date_notification
AFTER INSERT ON loans
FOR EACH ROW
EXECUTE FUNCTION notify_due_books();
