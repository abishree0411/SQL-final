
-- View for detailed order report
CREATE VIEW order_report AS
SELECT 
  o.id AS order_id,
  c.first_name || ' ' || c.last_name AS customer_name,
  o.order_date,
  p.name AS product_name,
  oi.quantity,
  oi.price,
  o.total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.id
JOIN order_items oi ON o.id = oi.order_id
JOIN products p ON oi.product_id = p.id;

-- Total sales report
SELECT 
  SUM(amount) AS total_sales
FROM payments;

-- Product sales summary
SELECT 
  p.name,
  SUM(oi.quantity) AS total_units_sold
FROM order_items oi
JOIN products p ON oi.product_id = p.id
GROUP BY p.name;
