
-- Insert products
INSERT INTO products (name, description, price, stock, category) VALUES
('Laptop', '15-inch laptop with 8GB RAM', 750.00, 50, 'Electronics'),
('Headphones', 'Noise-cancelling headphones', 150.00, 100, 'Electronics'),
('Coffee Maker', 'Automatic drip coffee maker', 85.00, 30, 'Home Appliances');

-- Insert customers
INSERT INTO customers (first_name, last_name, email, phone, address) VALUES
('Alice', 'Smith', 'alice@example.com', '1234567890', '123 Elm Street'),
('Bob', 'Johnson', 'bob@example.com', '0987654321', '456 Oak Avenue');

-- Insert orders
INSERT INTO orders (customer_id, order_date, status, total_amount) VALUES
(1, NOW(), 'Shipped', 900.00),
(2, NOW(), 'Processing', 150.00);

-- Insert order items
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 1, 750.00),
(1, 2, 1, 150.00),
(2, 2, 1, 150.00);

-- Insert payments
INSERT INTO payments (order_id, payment_date, payment_method, amount) VALUES
(1, NOW(), 'Credit Card', 900.00),
(2, NOW(), 'PayPal', 150.00);
